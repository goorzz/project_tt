package edu.mit.c301.vo;

public class UserrVO {
	
	private int no;
	private String r_group;   //조
	private String r_rank; //순위
	private String r_name; //나라
	private String r_count;  //경기수
	private String r_win; //승
	private String r_draw; //무
	private String r_lose; //패
	private String r_gain; //골득실
	private String r_wincount; //승점
	private String aa;

	
	
	public String getAa() {
		return aa;
	}
	public void setAa(String aa) {
		this.aa = aa;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getR_group() {
		return r_group;
	}
	public void setR_group(String r_group) {
		this.r_group = r_group;
	}
	public String getR_rank() {
		return r_rank;
	}
	public void setR_rank(String r_rank) {
		this.r_rank = r_rank;
	}
	public String getR_name() {
		return r_name;
	}
	public void setR_name(String r_name) {
		this.r_name = r_name;
	}
	public String getR_count() {
		return r_count;
	}
	public void setR_count(String r_count) {
		this.r_count = r_count;
	}
	public String getR_win() {
		return r_win;
	}
	public void setR_win(String r_win) {
		this.r_win = r_win;
	}
	public String getR_draw() {
		return r_draw;
	}
	public void setR_draw(String r_draw) {
		this.r_draw = r_draw;
	}
	public String getR_lose() {
		return r_lose;
	}
	public void setR_lose(String r_lose) {
		this.r_lose = r_lose;
	}
	public String getR_gain() {
		return r_gain;
	}
	public void setR_gain(String r_gain) {
		this.r_gain = r_gain;
	}
	public String getR_wincount() {
		return r_wincount;
	}
	public void setR_wincount(String r_wincount) {
		this.r_wincount = r_wincount;
	}

	
	
	
	
	
//	@Override
//	public String toString() {
//		return "UserrVO [no=" + no + ", r_group=" + r_group + ", r_rank=" + r_rank + ", r_name=" + r_name + ", r_count="
//				+ r_count + ", r_win=" + r_win + ", r_draw=" + r_draw + ", r_lose=" + r_lose + ", r_gain=" + r_gain
//				+ ", r_wincount=" + r_wincount + "]";
//	}
	

	
	
	
	
	
//	private int bno;
//	private String title;
//	private String content;
//	private String writer;
//	private String regdate;
//	private String updatedate;
//	
//	public int getBno() {
//		return bno;
//	}
//	public void setBno(int bno) {
//		this.bno = bno;
//	}
//	public String getTitle() {
//		return title;
//	}
//	public void setTitle(String title) {
//		this.title = title;
//	}
//	public String getContent() {
//		return content;
//	}
//	public void setContent(String content) {
//		this.content = content;
//	}
//	public String getWriter() {
//		return writer;
//	}
//	public void setWriter(String writer) {
//		this.writer = writer;
//	}
//	public String getRegdate() {
//		return regdate;
//	}
//	public void setRegdate(String regdate) {
//		this.regdate = regdate;
//	}
//	public String getUpdatedate() {
//		return updatedate;
//	}
//	public void setUpdatedate(String updatedate) {
//		this.updatedate = updatedate;
//	}
//	

	
}