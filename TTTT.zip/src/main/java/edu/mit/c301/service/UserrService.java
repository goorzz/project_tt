package edu.mit.c301.service;

import java.util.List;

import edu.mit.c301.vo.NewsVO;
import edu.mit.c301.vo.ScheduleVO;
import edu.mit.c301.vo.UserrVO;

public interface UserrService {
	
	//조별리그 쿼리 list
    public List<UserrVO> selectUser() throws Exception;
    public List<UserrVO> selectUserA(String alpha) throws Exception;
    public List<UserrVO> selectUserB() throws Exception;
    public List<UserrVO> selectUserC() throws Exception;
    public List<UserrVO> selectUserD() throws Exception;
    public List<UserrVO> selectUserE() throws Exception;
    public List<UserrVO> selectUserF() throws Exception;
    public List<UserrVO> selectUserG() throws Exception;
    public List<UserrVO> selectUserH() throws Exception;
	
	
	//news 쿼리 list
	public List<NewsVO> selectUsernews() throws Exception;
	
	
	//Schedule 쿼리 list
	public List<ScheduleVO> selectUserSchedule(String month1, String alpha1) throws Exception;
//	public List<ScheduleVO> selectUserSchedule1(String alpha2) throws Exception;

}
